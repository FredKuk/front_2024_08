import React from "react";
const withLoading = <MyProps extends object>(
  WrappedComponent: React.ComponentType<MyProps>
) => {
  return (props: MyProps & WithLoadingProps) => {
    console.log(props);
    console.log(typeof props);
    console.log("-----------");
    console.log(WrappedComponent);
    console.log(typeof WrappedComponent);

    if (props.isLoading) {
      return <h1 style={{ background: "red" }}>Loading ... </h1>;
    }
    return <WrappedComponent {...props}>INNER</WrappedComponent>;
  };
};
export default withLoading;
