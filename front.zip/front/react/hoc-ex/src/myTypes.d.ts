interface MyComponentProps {
  text: string;
}
interface WithLoadingProps {
  isLoading: boolean;
}
