import React from "react";
import "./App.css";
import withLoading from "./withLoading";

// CUSTOM USE
// HOC WITH
// LOADING PAGE / 권한 분리
// SET TIMEOUT...EX

const MyComponent = ({ text }: MyComponentProps) => {
  return <h1>DATA LOADING STATE : {text}</h1>;
};

const MyComponentWithLoading = withLoading<MyComponentProps & WithLoadingProps>(
  MyComponent
);

function App() {
  const [text, setText] = React.useState<string>("");
  const [isLoading, setIsLoading] = React.useState<boolean>(true);
  React.useEffect(() => {
    setTimeout(() => {
      setText("LOADING END!!");
      setIsLoading(false);
    }, 1000);
  }, []);
  console.log(" text ::: ", text);
  console.log(" loading ::: ", isLoading);
  return (
    <div className="App">
      <MyComponentWithLoading text={text} isLoading={isLoading} />
    </div>
  );
}

export default App;
