const FeedItem = (): JSX.Element => {
  return (
    <div>
      <h1>Title</h1>
      <p>content</p>
    </div>
  );
};

export default FeedItem;
