const Button = (): JSX.Element => {
  return (
    <button
      className="fab"
      onClick={() => {
        // addFeed();
      }}
    >
      +
    </button>
  );
};
export default Button;
