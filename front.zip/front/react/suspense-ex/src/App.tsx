import React from "react";
import logo from "./logo.svg";
import "./App.css";
// import FeedItem from "./FeedItem";
const FeedItem = React.lazy(() => import("./FeedItem"));

/*
SET TIME OUT 사용할거임
PROMISE 써서 강제로 비동기상황 만들것
Promise=> 익스큐터라고 부르는 녀석을 인자로 받음
(리졸브, 리젝)=>{
  if)성공적?
  resolve(성공시 넘겨주고싶은 데이터);

  if)실패?
  reject(실패시 넘겨주고싶은 데이터);
}

*/

const fetchData = (): Promise<string> => {
  return new Promise<string>((resolve) => {
    setTimeout(() => {
      resolve("RESOLVED ) DATA FETCH SUCCESS");
    }, 1000);
  });
};

const DataLoader = () => {
  const [text, setText] = React.useState<string | null>(null);

  React.useEffect(() => {
    fetchData().then((res) => {
      setText(res);
    });
  }, []);

  // if (!text) {
  //   throw new Promise((resolve) => setTimeout(resolve, 2000));
  // }

  return <div>{text}</div>;
};

function App() {
  return (
    <div className="App">
      <React.Suspense fallback={<h1> FALL BACK! LOADKING NOW</h1>}>
        <DataLoader />
        <FeedItem />
      </React.Suspense>
    </div>
  );
}

export default App;
