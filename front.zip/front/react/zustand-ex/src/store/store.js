import create from "zustand";

const catStore = create((set) => ({
  cat_arr: [],
  addCatArr: (newCat) =>
    set((state) => ({ cat_arr: [...state.cat_arr, newCat] })),
}));
export default catStore;
