import catStore from "./store/store";

//ZUSTAND는 store가 여러개 쓸수있음 VIEW를 관리할때만 씀
//REACT-QUERY 는 비동기 사용할 때 씀
const Cat = () => {
  console.log(catStore);
  catStore((state) => {
    console.log(state);
  });
  const { cat_arr, addCatArr } = catStore((state) => state);

  return (
    <div>
      <h3>CAT</h3>
      {cat_arr.map((cat, index) => {
        return <p key={`cat_${index}`}>{cat}</p>;
      })}
      <button
        onClick={() => {
          addCatArr("괭이");
        }}
      >
        CAT ADD
      </button>
    </div>
  );
};

function App() {
  return (
    <div className="App">
      <Cat />
    </div>
  );
}

export default App;
