import "./App.css";
import { RouterProvider } from "react-router-dom";
import router from "./router";

function App() {
  return (
    <div className="App">
      <h1>CAT AND DOG</h1>
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
