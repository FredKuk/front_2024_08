import { createBrowserRouter } from "react-router-dom";
import Home from "./components/Home";
import Cat from "./components/Cat";
import Dog from "./components/Dog";
import Layout from "./components/Layout";
const path_arr = [
  {
    id: 0,
    path: "/",
    element: <Layout />,
    children: [
      { id: 1, path: "/", element: <Home /> },
      { id: 2, path: "/cat/:cat_name?", element: <Cat /> },
      {
        id: 3,
        path: "/dog",
        element: <Dog />,
        children: [
          {
            id: 4,
            path: "./a",
            element: <Cat />,
          },
        ],
      },
    ],
  },
];

const router = createBrowserRouter(path_arr);
export default router;
