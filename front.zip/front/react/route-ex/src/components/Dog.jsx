import { Link, Outlet, useNavigate } from "react-router-dom";
const Dog = () => {
  const navigate = useNavigate();

  return (
    <>
      <Outlet />
      <h1>Dog</h1>
      <button
        onClick={() => {
          navigate("/cat/nabi");
        }}
      >
        Go cat Navi
      </button>
      <br />
      <Link to="/">Go to Home</Link>
    </>
  );
};
export default Dog;
