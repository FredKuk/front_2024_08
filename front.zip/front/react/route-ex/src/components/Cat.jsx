import { Link, useNavigate, useParams } from "react-router-dom";
const Cat = (props) => {
  const { cat_name } = useParams();
  console.log(cat_name);
  const navigate = useNavigate();
  console.log(navigate);
  return (
    <>
      <h1>Cat</h1>
      <h4>name={cat_name}</h4>
      <button
        onClick={() => {
          navigate("/dog");
        }}
      >
        DOG GOGO
      </button>
      <br />
      <Link to="/">Go to Home</Link>
    </>
  );
};
export default Cat;
