import { Link } from "react-router-dom";
const Home = () => {
  return (
    <>
      <h1>THIS IS HOME</h1>
      <Link to="/cat">GO TO CAT</Link>
      <br />
      <Link to="/dog">GO TO DOG</Link>
    </>
  );
};
export default Home;
