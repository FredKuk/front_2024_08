import { Link } from "react-router-dom";

const AComponent = () => {
  return (
    <div>
      <h1>A !</h1>
      <Link to={"/Bcomponent"}>GO TO B</Link>
      <br />
      <Link to={"/"}>GO TO HOME</Link>
    </div>
  );
};

const BComponent = () => {
  return (
    <div>
      <h1>B !</h1>
      <Link to={"/acomponent"}>GO TO A</Link>
      <br />
      <Link to={"/"}>GO TO HOME</Link>
    </div>
  );
};

export { AComponent, BComponent };
