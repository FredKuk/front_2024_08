type FeedListProps = {
  feed: FeedItem;
};

type FeedItem = {
  id: number;
  title: string;
  content: string;
};
