interface Feed {
  title: string;
  content: string;
}
