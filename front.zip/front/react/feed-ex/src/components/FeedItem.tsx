import React from "react";
const imgURL = "https://placehold.co/222x222";
const PreLoadImage = (): JSX.Element => {
  React.useEffect(() => {
    const img = new Image();
    img.src = imgURL;
  }, []);
  return <img src={imgURL} />;
};

const FeedItem = ({ feed }: FeedListProps): JSX.Element => {
  return (
    <div className="feed-item">
      <h1>{feed.title}</h1>
      {/* <img src={"https://placehold.co/222x80"} loading={"eager"} />
      <img src={"https://placehold.co/222x112"} loading={"lazy"} />
      <PreLoadImage /> */}
      <p>{feed.content}</p>
    </div>
  );
};

export default FeedItem;
