import React from "react";
const Form = (): JSX.Element => {
  const [title, setTitle] = React.useState<string>("");
  const [content, setContent] = React.useState<string>("");
  const [feed, setFeed] = React.useState<Feed>({ title: "", content: "" });

  const changeInputValue = (event: React.ChangeEvent): void => {
    setTitle("");
    setContent("");
    setFeed({ title: title, content: content });
    console.log(event);
    console.log(event.target.nodeValue);
  };

  const resetInput = (): void => {};

  return (
    <div>
      <form>
        <div>
          title :{" "}
          <input name="title" value={feed.title} onChange={changeInputValue} />
        </div>
        <div>
          content :{" "}
          <input
            name="content"
            value={feed.content}
            onChange={(e) => {
              changeInputValue(e);
            }}
          />
        </div>
        <button type="reset">reset</button>
        <button
          onClick={() => {
            console.log("ON_CLICK");
          }}
          type="submit"
        >
          submit
        </button>
        <button type="button">button</button>
      </form>
    </div>
  );
};
export default Form;
