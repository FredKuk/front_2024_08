import React from "react"; //다시 렌더링하지않음.
//데이터를 VIew하는게 아닌 이상 다 memo해도될듯
const Button = React.memo(
  ({ addFeed, a: myName }: { addFeed: () => void; a: string }): JSX.Element => {
    console.log("RE RENDER");

    console.log("a", myName);

    //
    return (
      <button
        className="fab"
        onClick={() => {
          addFeed();
        }}
      >
        +
      </button>
    );
  }
);
export default Button;

// import React from "react";
// const Button = (): JSX.Element => {
//   console.log("RE RENDER");
//   return (
//     <button
//       className="fab"
//       onClick={() => {
//         // addFeed();
//       }}
//     >
//       +
//     </button>
//   );
// };
// export default Button;
