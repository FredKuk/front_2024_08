import "./App.css";
import React from "react";
import FeedItem from "./components/FeedItem";
import Button from "./components/Button";
import Form from "./components/Form";

/*
*******package구조*******
app.tsx 
/pages
  /feed
    /feed.d.ts
    /list
      /header.tsx
      /list.tsx
      /fab.tsx
    /add
  /users
    /users.d.ts
    /detail ../.
    /list
      /header.tsx
      /list.tsx
      /fab.tsx
    /add
/shared or common
  /component
    /layout
    /button
    /div(column)
/func
  /util ..

************************
*/

const _feedList = [
  {
    id: 0,
    title: "feed Title1",
    content: "feed Content",
  },
];

function App() {
  const [feedList, setFeedList] = React.useState<FeedItem[]>(_feedList);

  const addFeed = (): void => {
    const item: FeedItem = {
      id: feedList.length,
      title: "title " + feedList.length,
      content: "content " + feedList.length,
    };
    setFeedList([...feedList, item]);
  };

  return (
    <div className="App">
      {feedList.map((feed, index) => {
        return <FeedItem key={`feed_${index}`} feed={feed} />;
      })}
      {/*추가하기버튼임*/}
      <button onClick={() => addFeed()}>피드추가하겠음</button>
      <Form />
      <div>
        <Button addFeed={addFeed} a={"11231231"} />
      </div>
    </div>
  );
}

export default App;
