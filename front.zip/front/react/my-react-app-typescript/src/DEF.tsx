export const DEF = ({ message, message2 }: MyMessage): JSX.Element => {
  return (
    <>
      <h2 style={{ background: "red" }}>{message}</h2>
      <h2 style={{ background: "blue" }}>{message2}</h2>
    </>
  );
};
