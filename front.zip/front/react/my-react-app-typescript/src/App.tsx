import React from "react";
import logo from "./logo.svg";
import "./App.css";

const something: {
  message: string;
} = { message: "test" };

// type MyMessage = { message: string; message2: string };
// xxx.d.tsx 를 먼저 type 컴파일러가 읽어서 전역적으로 쓸수있음. 다른 디렉토리 있어도 사용가능.

const ABCD = ({
  message,
  message2,
}: {
  message: string;
  message2: string;
}): JSX.Element => {
  return (
    <>
      <div style={{ background: "red" }}>{message}</div>
      <div style={{ background: "blue" }}>{message2}</div>
    </>
  );
};

const ABCD2 = ({ message, message2 }: MyMessage): JSX.Element => {
  return (
    <>
      <h2 style={{ background: "red" }}>{message}</h2>
      <h2 style={{ background: "blue" }}>{message2}</h2>
    </>
  );
};

function App() {
  const [msg, setMsg] = React.useState<string>("제목바꿔보기"); // String
  // const [msg, setMsg] = React.useState<string>(); // undefined
  console.log(typeof msg);
  return (
    <div className="App">
      <h1>{msg}</h1>
      <ABCD message={"RED"} message2={"BLUE"} />
      <hr></hr>
      <ABCD2 message={"RED"} message2={"BLUE"} />
      <button
        onClick={() => {
          setMsg("title");
        }}
      >
        changeMsg
      </button>
    </div>
  );
}

export default App;
