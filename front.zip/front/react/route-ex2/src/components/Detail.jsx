import { useParams } from "react-router-dom";
const Detail = () => {
  const { item } = useParams();
  console.log(item);
  return (
    <div>
      <h1>DETAIL PAGE!</h1>
      <p>{item}</p>
    </div>
  );
};
export default Detail;
