import { useNavigate, Link } from "react-router-dom";
const List = () => {
  const navigate = useNavigate();
  return (
    <div>
      <h3
        onClick={() => {
          navigate("/detail");
        }}
      >
        data 1
      </h3>
      <h3>data 2</h3>
      <h3>data 3</h3>
      <Link to="/detail">상세페이지 가기</Link>
    </div>
  );
};
export default List;
