import { createBrowserRouter } from "react-router-dom";
import List from "./components/List";
import Detail from "./components/Detail";
const path_arr = [
  {
    id: 0,
    path: "/",
    element: <List />,
  },
  {
    id: 1,
    path: "/detail/:item?",
    element: <Detail />,
  },
];

const router = createBrowserRouter(path_arr);
export default router;
