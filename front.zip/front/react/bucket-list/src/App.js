import "./App.css";
import { useState } from "react";
import Bucket from "./component/Bucket";
import { BucketList } from "./component/BucketList";
import BucketWriteForm from "./component/BucketWriteForm";
import { BucketListData } from "./component/BucketListData";
import { Router, RouterProvider } from "react-router-dom";
import routerFn from "./router";
// import BucketDetail from "./component/BucketDetail";

function App() {
  const [myBucketList, setMyBucketList] = useState(BucketListData);

  function addList(addItem) {
    setMyBucketList([...myBucketList, { item: addItem, completed: false }]);
  }

  function delList(id) {
    const changeBucket = myBucketList.filter((itemId, index) => {
      return index != id;
    });
    setMyBucketList(changeBucket);
  }

  const router = routerFn(myBucketList, delList);

  return (
    <div className="App">
      <h1>버킷리스트</h1>
      <RouterProvider router={router} />
      <BucketWriteForm addMyBucketList={addList} />
    </div>
  );
}

export default App;
