import { createBrowserRouter } from "react-router-dom";

import App from "./App";
import BucketList from "./component/BucketList";
import BucketDetail from "./component/BucketDetail";

const routerFn = (myBucketList, delList) => {
  const path_arr = [
    {
      id: 0,
      path: "/",
      element: <BucketList myBucketList={myBucketList} delList={delList} />,
    },
    {
      id: 1,
      path: "/detail",
      element: <BucketDetail />,
    },
  ];

  const router = createBrowserRouter(path_arr);
  return router;
};

export default routerFn;
