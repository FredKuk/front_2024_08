import styled from "styled-components";
import { Link, useNavigate } from "react-router-dom";
const BucketDiv = styled.div`
  background: whitesmoke;
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  max-width: 30rem; /* maxWidth → max-width */
  padding: 1rem;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
`;

const DelButton = styled.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 5px;
  background-color: red;
  color: white;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: purple;
  }
`;
function Bucket({ id, item, completed, delMyBucketList }) {
  const navigate = useNavigate();
  return (
    <BucketDiv>
      <h5>
        <Link to="/detail">Link : {item}</Link>
      </h5>
      <h5
        onClick={() => {
          navigate("/detail");
        }}
      >
        Navigate : {item}
      </h5>
      {completed ? <p>완료했어요!</p> : <p>못했어요아직!</p>}
      <DelButton onClick={() => delMyBucketList(id)}>삭제</DelButton>
    </BucketDiv>
  );
}
export default Bucket;
