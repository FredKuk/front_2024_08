import { BucketListStyle } from "./BucketListStyle";
const BucketDetail = () => {
  return (
    <BucketListStyle>
      <h5>상세페이지입니다!</h5>
    </BucketListStyle>
  );
};
export default BucketDetail;
