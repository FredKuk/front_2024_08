import styled from "styled-components";
import { useRef } from "react";
const BucketWriteFormStyle = styled.div`
  max-width: 30rem; /* maxWidth → max-width */
  width: 50vw;
  height: 70vh;
  margin: 0 auto;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
  display: flex;
  flex-direction: column;
`;
const Input = styled.input`
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1rem;
`;

const AddButton = styled.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: white;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #0056b3;
  }
`;

function BucketWriteForm({ addMyBucketList, delMyBucketList }) {
  const inputRef = useRef(null);
  return (
    <BucketWriteFormStyle>
      <Input ref={inputRef} placeholder="버킷 리스트 항목 입력" />
      <AddButton
        onClick={() => {
          addMyBucketList(inputRef.current.value);
        }}
      >
        추가
      </AddButton>
    </BucketWriteFormStyle>
  );
}
export default BucketWriteForm;
