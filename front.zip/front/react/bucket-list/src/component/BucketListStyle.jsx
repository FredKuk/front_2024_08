import styled from "styled-components";
export const BucketListStyle = styled.div`
  max-width: 30rem; /* maxWidth → max-width */
  width: 50vw;
  height: 70vh;
  margin: 0 auto;
  border: 1px solid red;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
`;
