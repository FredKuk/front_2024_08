export const BucketListData = [
  {
    item: "고양이 밥주기",
    completed: false,
  },
];
