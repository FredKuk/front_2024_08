import styled from "styled-components";
import Bucket from "./Bucket";
import { BucketListStyle } from "./BucketListStyle";
// const BucketListStyle = styled.div`
//   max-width: 30rem; /* maxWidth → max-width */
//   width: 50vw;
//   height: 70vh;
//   margin: 0 auto;
//   border: 1px solid red;
//   border-radius: 10px;
//   display: flex;
//   flex-direction: column;
//   justify-content: flex-start;
// `;

const BucketList = ({ myBucketList, delList }) => {
  return (
    <BucketListStyle>
      {myBucketList.map((myBucketList, index) => {
        return (
          <Bucket
            key={index}
            {...myBucketList}
            id={index}
            delMyBucketList={delList}
          />
        );
      })}
    </BucketListStyle>
  );
};
export default BucketList;
