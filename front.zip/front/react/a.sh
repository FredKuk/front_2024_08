Get-ChildItem -Path "C:\Users\user\Downloads\redis" -Recurse -File | 
    Select-Object -ExpandProperty Extension |
    Where-Object {$_} |
    ForEach-Object {$_.TrimStart('.')} |
    Sort-Object -Unique

    