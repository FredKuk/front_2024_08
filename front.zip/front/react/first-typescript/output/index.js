"use strict";
var myString;
var 내변수;
내변수 = { a: 5, b: "" };
console.log(내변수);
var 내변수2;
내변수2 = { a: true, b: true };
console.log(내변수2);
var 내변수3;
내변수3 = { a: true, b: "" };
console.log(내변수3);
var 내변수4;
내변수4 = { a: 5, b: "", c: true };
console.log(내변수2);
var post = {
    title: "",
    content: "asdf",
};
function lengthChecker(input) {
    return input.length;
}
console.log(lengthChecker({ length: 5 }));
console.log(lengthChecker("1234"));
console.log(lengthChecker([1, 2, 3, 4, 5, 6, 7]));
console.log(lengthChecker(1903583985));
function stringChecker(input) {
    return input.toString();
}
console.log(stringChecker(555));
