declare namespace MyNamespace {
    type A = string;
}
declare let myString: MyNamespace.A;
interface MyInterface {
    a: number;
    b: string;
}
declare let 내변수: MyInterface;
interface MyInterface {
    a: boolean;
    b: boolean;
}
declare let 내변수2: MyInterface;
interface MyInterface {
    a: boolean;
}
declare let 내변수3: MyInterface;
interface MyInterface {
    c: boolean;
}
declare let 내변수4: MyInterface;
interface Post {
    title: string;
}
interface DetailPost extends Post {
    content: string;
}
declare let post: DetailPost;
interface lengthCheck {
    length: number;
}
declare function lengthChecker<T extends lengthCheck>(input: T): number;
interface StringCheck {
    toString: () => {};
}
declare function stringChecker<T extends StringCheck>(input: T): {};
