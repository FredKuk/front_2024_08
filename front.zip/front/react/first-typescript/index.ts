//interface

namespace MyNamespace {
  export type A = string;
  type B = number;
}

let myString: MyNamespace.A;

interface MyInterface {
  a: number;
  b: string;
}

let 내변수: MyInterface;
내변수 = { a: 5, b: "" };
console.log(내변수);

interface MyInterface {
  a: boolean;
  b: boolean;
}

let 내변수2: MyInterface;
내변수2 = { a: true, b: true };
console.log(내변수2);

interface MyInterface {
  a: boolean;
}

let 내변수3: MyInterface;
내변수3 = { a: true, b: "" };
console.log(내변수3);

interface MyInterface {
  c: boolean;
}

let 내변수4: MyInterface;
내변수4 = { a: 5, b: "", c: true };
console.log(내변수2);

interface Post {
  title: string;
}

interface DetailPost extends Post {
  content: string;
}
let post: DetailPost = {
  title: "",
  content: "asdf",
};

interface lengthCheck {
  length: number;
}
function lengthChecker<T extends lengthCheck>(input: T) {
  return input.length;
}

console.log(lengthChecker({ length: 5 }));
console.log(lengthChecker<string>("1234"));
console.log(lengthChecker<number[]>([1, 2, 3, 4, 5, 6, 7]));
console.log(lengthChecker<number>(1903583985)); //ERROR

//.toString
// function a<T extends number>() {}

interface StringCheck {
  toString: () => {};
}
function stringChecker<T extends StringCheck>(input: T) {
  return input.toString();
}
console.log(stringChecker(555));
