//1 상태값 만들기 catArr
//->redux store
//->store가 가지고 있는,   값
//->값 변경을 위한,        Reducer
//->리듀서를 만들기 위한,  Action
//2 컴포넌트가 이 상태를 구독하도록 함
import { combineReducers, createStore } from "redux";
import cat from "./modules/cat";
import dog from "./modules/dog";
const reducer = combineReducers({
  catReducer: cat,
  dogReducer: dog,
  //cat
});

export const store = createStore(reducer);
