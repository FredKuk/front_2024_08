const initialState = {
  dog_arr: [],
};
// action Type
const ADD_DOG = "dog/ADD_DOG";

// action 생성
// 1. new_cat이라는 "고양이 String"을 받아오는 액션 생성 함수
export const addDog = (new_dog) => {
  return {
    type: ADD_DOG,
    new_dog: new_dog,
  };
};

//state를 받아올 건데, state에 아무값도 없으면 initialState를 기본 파라매터로 사용해라
export default function (state = initialState, action) {
  //상태값을 리턴하면됨
  if (action.type === ADD_DOG) {
    console.log("##########");
    console.log(state);
    console.log("##########");
    return { ...state, dog_arr: [...state.dog_arr, action.new_dog] };
  }
  return state;
}
