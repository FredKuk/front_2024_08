const initialState = {
  cat_arr: [],
};
// action Type
const ADD_CAT = "cat/ADD_CAT";

// action 생성
// 1. new_cat이라는 "고양이 String"을 받아오는 액션 생성 함수
export const addCat = (new_cat) => {
  return {
    type: ADD_CAT,
    new_cat: new_cat,
  };
};

//state를 받아올 건데, state에 아무값도 없으면 initialState를 기본 파라매터로 사용해라
export default function (state = initialState, action) {
  //상태값을 리턴하면됨
  if (action.type === ADD_CAT) {
    console.log("---------------");
    console.log(state);
    console.log("---------------");
    return { ...state, cat_arr: [...state.cat_arr, action.new_cat] };
  }
  return state;
}
