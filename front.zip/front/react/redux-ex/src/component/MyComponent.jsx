import { useSelector, useDispatch } from "react-redux";
import { addCat } from "../redux/modules/cat";
import { addDog } from "../redux/modules/dog";
// import { useDispatch } from "redux";
export const Home = () => {
  return (
    <div>
      <h1>HOME!</h1>
    </div>
  );
};
export const Cat = () => {
  const reduxStore = useSelector((state) => {
    console.log("---STORE : ---");
    console.log(state);
    console.log("--------------");
  });
  const dispatch = useDispatch();

  return (
    <div>
      <h1>CAT</h1>
      <button
        onClick={() => {
          dispatch(addCat("고양이"));
        }}
      >
        catButton
      </button>
    </div>
  );
};

export const Dog = () => {
  const reduxStore = useSelector((state) => {
    console.log("---STORE : ---");
    console.log(state);
    console.log("--------------");
  });
  const dispatch = useDispatch();
  return (
    <div>
      <h1>DOG</h1>
      <button
        onClick={() => {
          dispatch(addDog("강아지"));
        }}
      >
        dogButton
      </button>
    </div>
  );
};
