import React from "react";
import { Cat, Dog, Home } from "./component/MyComponent";
import { Provider } from "react-redux";
import { store } from "./redux/store";
function App() {
  return (
    <div className="App">
      <Provider store={store}>
        <Home />
        <Cat />
        <Dog />
      </Provider>
    </div>
  );
}

export default App;
