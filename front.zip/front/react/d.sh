Get-ChildItem -Path "C:\Users\user\Downloads\redis" -Recurse -File | 
    Where-Object {$_.Name -like "*.*"} |
    ForEach-Object {   if ($_.Name -match '\.([^.]+)$') {echo $_.Name}}