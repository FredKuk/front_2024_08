Get-ChildItem -Path "C:\Users\user\Downloads\redis" -Recurse -File | 
    Select-Object -ExpandProperty Extension |
    Where-Object {$_.Name -like "*.*"} |
    ForEach-Object {  if ($_.Name -match '\.([^.]+)$') {$matches[1]}}|
    Sort-Object -Unique

    