type WindowSize = {
  width: number;
  height: number;
};
