import React from "react";
//커스텀훅에서는 왠만해선 useEffect 가 무조건 들어감
//컴포넌트 안에서.... 하나의 ...... 먼소리.. 모름

// function setWindowSize2({ width, height }: WindowSize) {
//   width = window.innerWidth;
//   height = window.innerHeight;
// }
const useWindowSize = () => {
  const [windowSize, setWindowSize] = React.useState<WindowSize>({
    width: window.innerWidth,
    height: window.innerHeight,
  });

  const windowSize2: WindowSize = {
    width: window.innerWidth,
    height: window.innerHeight,
  };

  React.useEffect(() => {
    const handleWindowSize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
      //   setWindowSize2(windowSize2);
    };

    window.addEventListener("resize", handleWindowSize);
    return () => {
      window.removeEventListener("resize", handleWindowSize);
    };
  }, []);
  return windowSize;
  //   console.log(windowSize2);
  //   return windowSize2;
};
export default useWindowSize;
