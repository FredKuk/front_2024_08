import React from "react";
import useWindowSize from "./useWindowSize";

const MyWindowSizeView = () => {
  const windowSize = useWindowSize();
  return (
    <div>
      <p>width : {windowSize.width}</p>
      <p>width : {windowSize.height}</p>
    </div>
  );
};

function App() {
  return (
    <div className="App">
      <MyWindowSizeView />
    </div>
  );
}

export default App;
