import axios from "axios";

export const callFetchSleepTimes = async () => {
  return await axios.get("http://localhost:5001/sleep_times");
};
