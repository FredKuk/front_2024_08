import { useSelector, useDispatch } from "react-redux";
import React from "react";
// import { catSlice } from "../redux/slice/cat";
import { addCat } from "../redux/slice/cat";
import { addDog } from "../redux/slice/dog";
import { fetchSleepTimes } from "../redux/slice/sleep";
import { callFetchSleepTimes } from "../sleepApi";
// import { addCat as adCatts } from "../redux/slice/dog";

export const SleepList = () => {
  const sleepState = useSelector((state) => state.sleep);
  console.log(sleepState);
  const dispatch = useDispatch();

  //*********extraReducer 빌더패턴 안쓰고 하는 방법임
  const callAndStoreSleepTimesData = async () => {
    const res = await callFetchSleepTimes();
    // dispatch(sleepList 추가하는 액션생성함수 (response.data));
    return res.data;
  };
  React.useEffect(() => {
    callAndStoreSleepTimesData();
  }, []);

  return (
    <div>
      <h3>SLEEP {sleepState.status}</h3>
      <button
        onClick={() => {
          dispatch(fetchSleepTimes());
        }}
      >
        목록불러오기
      </button>
    </div>
  );
};

//실제 SLICE NAME과 REDUCER 이름이 같으면, as로 회피해서 호출해버리면 둘다 호출됨
// -> REDUX처럼 모든 reducer를 순회한다는 것을 알 수 있음
export const Dog = () => {
  const { dog_arr } = useSelector((state) => state.dog);
  // console.log(dog_arr);
  const dispatch = useDispatch();
  return (
    <div>
      <h1>Dog</h1>
      {dog_arr.map((dog_item, index) => {
        return <h3 key={`dog_${index}`}>{dog_item}</h3>;
      })}
      <button
        onClick={() => {
          dispatch(addDog("강아지"));
        }}
      >
        ADD DOG BUTTON
      </button>
    </div>
  );
};

export const Cat = () => {
  //   const allState = useSelector((state) => state);
  // const catState = useSelector((state) => state.cat);
  const { cat_arr } = useSelector((state) => state.cat);

  const makePromise = (isResolve, num) => {
    console.log(num);
    const promise = new Promise((resolve, reject) => {
      window.setTimeout(() => {
        if (isResolve) {
          resolve(true);
        }
        reject(true);
      }, 600);
    });
    return promise;
  };

  const dispatch = useDispatch();
  //   console.log(catSlice);
  return (
    <div>
      <h1>Cat</h1>
      {cat_arr.map((cat_item, index) => {
        return <h3 key={`cat_${index}`}>{cat_item}</h3>;
      })}
      <button
        onClick={() => {
          dispatch(addCat("고양이"));
        }}
      >
        ADD CAT BUTTON
      </button>

      <button
        onClick={async () => {
          console.log("TRUE");
          const something1 = makePromise(true, 1);
          console.log(something1);
          const something2 = makePromise(true, 2);
          console.log(something2);
          const something3 = await makePromise(true, 3);
          console.log(something3);
          const something4 = makePromise(true, 4);
          console.log(something4);
        }}
      >
        Console!
      </button>
    </div>
  );
};

export const Home = () => {
  return (
    <div>
      <h1>Home</h1>
    </div>
  );
};
