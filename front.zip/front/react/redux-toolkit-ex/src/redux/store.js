// 리듀서를 묶어서 스토어를 만들어야 합니다!
// 리액트는 모노 리듀서 스토어 기반입니다!
import { combineReducers } from "redux";
import { configureStore } from "@reduxjs/toolkit";
import cat from "./slice/cat";
import dog from "./slice/dog";
import sleep from "./slice/sleep";
import logger from "redux-logger"; // redux-logger를 임포트합니다.

// THUNK! 청크
// ->비동기작업할때 쓰는 패턴임
// asis =>디스패치를 한다 -> 어떤 액션 객체를 전달하는 행위임 -> 리듀서에다가..
// 청크 =>디스패치를 한다 -> **어떤함수를 실행시킨 결과물을 전달하겠다 -> 리듀서에다가..

// 지금이 어느 환경인 지 알려줘요. (개발환경, 프로덕션(배포)환경 ...)
const env = process.env.NODE_ENV;
// 필요한 다른 미들웨어를 추가할 수 있습니다.
const middlewares = [logger];

const rootReducer = combineReducers({
  cat,
  dog,
  sleep,
});

const store = configureStore({
  reducer: rootReducer, // rootReducer로 통합된 리듀서 사용
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(middlewares),
  // 여기에 devTools 옵션이나 추가적인 미들웨어 등을 설정할 수 있습니다.
  devTools: env !== "production", // 개발 환경에서만 DevTools를 사용
});

// const store = configureStore({
//   reducer: rootReducer,
// });

export default store;
