import { createSlice } from "@reduxjs/toolkit";

//기본적으로 가지고 있을 값
// 뭐를 어떻게 할거다 -> 액션
//액션대로 처리한다 -> 리듀서 안에서 했던 분기처리임!

// catSlice는 슬라이스 객체임
const catSlice = createSlice({
  name: "cat",
  initialState: {
    cat_arr: [],
  },
  reducers: {
    addCat: (state, action) => {
      //state의 변경이 필요할 경우 이곳에서 해야함
      console.log(state);
      console.log(action);
      state.cat_arr = [...state.cat_arr, action.payload];
    },
  },
});

// export { catSlice };
export const { addCat } = catSlice.actions;
export default catSlice.reducer;
