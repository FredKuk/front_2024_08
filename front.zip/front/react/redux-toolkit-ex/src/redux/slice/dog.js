import { createSlice } from "@reduxjs/toolkit";

//기본적으로 가지고 있을 값
// 뭐를 어떻게 할거다 -> 액션
//액션대로 처리한다 -> 리듀서 안에서 했던 분기처리임!

// catSlice는 슬라이스 객체임
const dogSlice = createSlice({
  name: "dog",
  initialState: {
    dog_arr: [],
  },
  reducers: {
    addDog: (state, action) => {
      //state의 변경이 필요할 경우 이곳에서 해야함
      // state.dog_arr = [...state.dog_arr, action.payload];
      state.dog_arr.push(action.payload);
    },
  },
});

export const { addDog } = dogSlice.actions;
// export const { addCat } = dogSlice.actions;
export default dogSlice.reducer;
