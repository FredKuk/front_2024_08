import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const requestURL = "http://localhost:5001/sleep_times";
export const fetchSleepTimes = createAsyncThunk(
  "sleep/fetchSleepTimes",
  async () => {
    const response = await axios.get(requestURL);
    return response.data;
  }
);
//액션을 일으키면,
//  -> 함수에서 액션을 받아서
//      ->어떠한처리 후 다시 리턴해서 리듀서에 줌

const sleepSlice = createSlice({
  name: "sleep",
  initialState: {
    sleepTimes: [],
    status: "IDLE", // loading, success, fail, ....
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchSleepTimes.pending, (state, action) => {
        console.log("처리중입니다~");
        console.log("처리중인state&action : ", state, action);
        state.status = "loading";
      })
      .addCase(fetchSleepTimes.fulfilled, (state, action) => {
        console.log("처리끝났습니다~");
        console.log("처리중인state&action : ", state, action);
        state.status = "done";
      })
      .addCase(fetchSleepTimes.rejected, (state, action) => {
        console.log("실패하였습니다~");
        console.log("처리중인state&action : ", state, action);
      });
  },
});

export default sleepSlice.reducer;
