import { Provider } from "react-redux";
import { Cat, Home, Dog, SleepList } from "./component/MyComponent";
import store from "./redux/store";
function App() {
  return (
    <div className="App">
      <Provider store={store}>
        <Home />
        <SleepList />
        <Cat />
        <Dog />
      </Provider>
    </div>
  );
}

export default App;
