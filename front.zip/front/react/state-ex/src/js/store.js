import React from "react";

//context API
//for making State, Subscribe, modify
//but Sate, Subscribe, Not modify // using useState

export const CatStore = React.createContext();
export const DogStore = React.createContext();
export const AboutTextStore = React.createContext();
