import { CatStore, DogStore, AboutTextStore } from "../js/store";
import { useContext, useRef } from "react";
export const Home = () => {
  return (
    <div>
      <h1>Home!</h1>
      <p>My Children</p>
      <Cat />
      <Dog />
    </div>
  );
};

export const About = () => {
  const inputRef = useRef(null);
  const { aboutText, setAboutText } = useContext(AboutTextStore);
  return (
    <div>
      <h1>About!</h1>
      <h5>{aboutText}</h5>
      <input ref={inputRef} placeholder="아무거나 입력하셈" />
      <button
        onClick={() => {
          setAboutText(inputRef.current.value);
        }}
      >
        AboutChange
      </button>
    </div>
  );
};

export const Cat = () => {
  return (
    <CatStore.Consumer>
      {(value) => {
        return (
          <div>
            <h1>Cat!</h1>
            <div>
              {value.catArr.map((cat, index) => {
                return <p key={`cat_${index}`}>{cat}</p>;
              })}
            </div>
            <button
              onClick={() => {
                value.setCatArr([1, 2, 3, 4]);
              }}
            >
              change
            </button>
          </div>
        );
      }}
    </CatStore.Consumer>
  );
};

export const Dog = () => {
  return (
    <DogStore.Consumer>
      {({ dogArr }) => {
        return (
          <div>
            <h1>Dog!</h1>
            <h3>###############</h3>

            <div>
              {dogArr.map((dog, index) => {
                return <p key={`dog_${index}`}>{dog}</p>;
              })}
            </div>
            <h3>###############</h3>
          </div>
        );
      }}
    </DogStore.Consumer>
  );
};
