import React from "react";
import { About, Home } from "./components/MyComponent";
import { DogStore, CatStore, AboutTextStore } from "./js/store";
function App() {
  const [catArr, setCatArr] = React.useState(["페르시안", "나비"]);
  const [dogArr, setDogArr] = React.useState(["시츄", "푸들"]);
  const [aboutText, setAboutText] = React.useState("에베베베베베");
  return (
    <div className="App">
      <DogStore.Provider value={{ dogArr: dogArr, setDogArr: setDogArr }}>
        <CatStore.Provider value={{ catArr: catArr, setCatArr: setCatArr }}>
          <Home />
        </CatStore.Provider>
      </DogStore.Provider>
      <AboutTextStore.Provider value={{ aboutText, setAboutText }}>
        <About />
      </AboutTextStore.Provider>
    </div>
  );
}

export default App;
