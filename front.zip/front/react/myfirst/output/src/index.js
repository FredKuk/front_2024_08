"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var client_1 = require("react-dom/client");
require("./index.css");
var reportWebVitals_1 = require("./reportWebVitals");
var root = client_1.default.createRoot(document.getElementById("root"));
root.render(/>
    < /React.StrictMode>);
(0, reportWebVitals_1.default)();
