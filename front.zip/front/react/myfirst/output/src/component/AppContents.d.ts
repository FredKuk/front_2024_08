declare const AppContents: () => import("react").JSX.Element;
export default AppContents;
