declare function TodoCard({ work }: {
    work: any;
}): import("react").JSX.Element;
export default TodoCard;
