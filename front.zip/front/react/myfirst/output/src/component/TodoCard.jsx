"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
Object.defineProperty(exports, "__esModule", { value: true });
var styled_components_1 = require("styled-components");
var CardStyle = styled_components_1.default.div(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        width: 200,\n        border: 1px solid #000000,\n        padding: 10px,\n        flexDirection: column,\n"], ["\n        width: 200,\n        border: 1px solid #000000,\n        padding: 10px,\n        flexDirection: column,\n"])));
function TodoCard(_a) {
    var work = _a.work;
    return (<CardStyle $cardIndex={10}>
      <p className="Card-text"> 오늘 할 일</p>
      <h4>{work.name}</h4>
      <h4>{work.price}</h4>
      <button>완료</button>
    </CardStyle>);
}
exports.default = TodoCard;
var templateObject_1;
