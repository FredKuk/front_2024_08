"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = require("react");
var TodoCard_1 = require("./TodoCard");
var TodoInput_1 = require("./TodoInput");
var styled_components_1 = require("styled-components");
var BackgroundDiv = styled_components_1.default.div(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n  background-color: rgba(\n    0,\n    125,\n    125,\n    ", "\n  );\n"], ["\n  background-color: rgba(\n    0,\n    125,\n    125,\n    ", "\n  );\n"])), function (props) { return (props.$cardIndex * 5) / 10; });
var todoLists = [
    { name: "꽃에물주기", price: 4000 },
    { name: "밥먹기", price: 2000 },
    { name: "놀기" },
];
var AppContents = function () {
    var _a = (0, react_1.useState)(todoLists), todoList = _a[0], setTodoList = _a[1];
    console.log(todoList);
    return (<div style={{
            display: "flex",
            alignContent: "center",
            justifyContent: "space-between",
            gap: 10,
        }}>
      {todoList.map(function (todo, index) {
            console.log(index);
            return (<BackgroundDiv key={index} $cardIndex={index}>
            <TodoCard_1.default work={todo}/>
          </BackgroundDiv>);
        })}
      <TodoInput_1.default />
    </div>);
};
exports.default = AppContents;
var templateObject_1;
