declare const TitleComponent: () => import("react").JSX.Element;
export default TitleComponent;
