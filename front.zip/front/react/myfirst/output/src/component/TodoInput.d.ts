declare const TodoInput: () => import("react").JSX.Element;
export default TodoInput;
