"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("./App.css");
var AppContents_1 = require("./component/AppContents");
function App() {
    return className = "App" >
        />
        < AppContents_1.default /  >
        /div>;
    ;
}
exports.default = App;
