import "./App.css";
declare function App(): boolean;
export default App;
