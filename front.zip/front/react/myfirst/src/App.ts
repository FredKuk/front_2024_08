import logo from "./logo.svg";
import "./App.css";
import { Fragment } from "react";
import AppContents from "./component/AppContents";
import TitleComponent from "./component/TitleComponent";
import styled from "styled-components"; // styled-components를 임포트해요!

//혹은 스타일 오브젝트를 변수로 만들고 쓸 수 있어요!
function App() {
  return (
    <div className="App">
      <TitleComponent />
      <AppContents />
    </div>
  );
}

export default App;
