import { useState } from "react";
import TodoCard from "./TodoCard";
import TodoInput from "./TodoInput";
import styled from "styled-components"; // styled-components를 임포트해요!

const BackgroundDiv = styled.div`
  background-color: rgba(
    0,
    125,
    125,
    ${(props) => (props.$cardIndex * 5) / 10}
  );
`;

const todoLists = [
  { name: "꽃에물주기", price: 4000 },
  { name: "밥먹기", price: 2000 },
  { name: "놀기" },
];

const AppContents = () => {
  const [todoList, setTodoList] = useState(todoLists);
  console.log(todoList);
  return (
    <div
      style={{
        display: "flex",
        alignContent: "center",
        justifyContent: "space-between",
        gap: 10,
      }}
    >
      {todoList.map((todo, index) => {
        console.log(index);
        return (
          <BackgroundDiv key={index} $cardIndex={index}>
            <TodoCard work={todo} />
          </BackgroundDiv>
        );
      })}
      <TodoInput />
    </div>
  );
};
export default AppContents;
