const TodoInput = () => {
  return (
    <div style={{ width: 100, flexDirection: "column" }}>
      <div>
        할일 : <input type="text"></input>
      </div>
      <div>
        비용 : <input type="text"></input>
      </div>
      <button style={{ width: 100 }}>추가</button>
    </div>
  );
};
export default TodoInput;
