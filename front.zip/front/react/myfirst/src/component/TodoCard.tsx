import styled from "styled-components"; // styled-components를 임포트해요!

const CardStyle = styled.div`
        width: 200,
        border: 1px solid #000000,
        padding: 10px,
        flexDirection: column,
`;

function TodoCard({ work }) {
  return (
    <CardStyle $cardIndex={10}>
      <p className="Card-text"> 오늘 할 일</p>
      <h4>{work.name}</h4>
      <h4>{work.price}</h4>
      <button>완료</button>
    </CardStyle>
  );
}
export default TodoCard;
