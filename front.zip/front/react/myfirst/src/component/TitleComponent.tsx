import styled from "styled-components"; // styled-components를 임포트해요!

// 상수를 선언하고, (변수여도 OK!)
// styled.[원하는 태그 명]을 적어요!
// 백틱을 열고 (`` ~랑 같이 있어요!)
// style을 입히기 위한 css 코드를 그대로 복사해서 붙여주면 됩니다!
const Title = styled.h1`
  color: blue;
  text-decoration: underline;
`;

const TitleComponent = () => {
  return <h1> 오늘 할 일</h1>;
};
export default TitleComponent;
