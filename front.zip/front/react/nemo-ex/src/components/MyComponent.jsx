const ComponentA = ({ number }) => {
  console.log("A!!");
  return <h1>A!! {number}</h1>;
};

const ComponentB = ({ setnumber }) => {
  console.log("B!!");
  return <h1>B!!</h1>;
};
export { ComponentA, ComponentB };
