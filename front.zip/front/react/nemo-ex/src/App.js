import "./App.css";
import React from "react";
function App() {
  const [text, setText] = React.useState("");
  const inputRef = React.useRef(null);
  const h1Ref = React.useRef(null);

  console.log("out", inputRef);
  React.useEffect(() => {}, []);

  return (
    <div className="App">
      <h1 ref={h1Ref} onClick={() => console.log("CLICKED")}>
        asdfasdf
      </h1>
      <input ref={inputRef} />
      <button
        onClick={() => {
          setText(inputRef.current.value);
        }}
      >
        텍스트 복사하기
      </button>
      <div>COPYIED TEXT : {text}</div>
    </div>
  );
}

export default App;
