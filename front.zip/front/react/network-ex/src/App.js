import "./App.css";
import React from "react";
import axios from "axios";
import customAxios from "./customAxios";

const host = "http://localhost:5001";
const options = "http://localhost:5001/sleep_times";
function App() {
  const [sleepList, setSleepList] = React.useState([]);

  /**********************************ASYNC AWAIT  ***************************************/

  let tempList = [];
  const callSleepTimes = async () => {
    console.log("start: ", sleepList);
    const sleep_times_response = await fetch(options);
    console.log("raw", sleep_times_response);
    const sleepData = await sleep_times_response.json();
    console.log("json", sleepData);
    setSleepList(sleepData);
  };

  const sleep_data = {
    id: "5",
    day: "토",
    time: "12:00",
  };

  const addSleepTimes = async () => {
    await fetch(options, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sleep_data),
    });

    setSleepList([...sleepList, sleep_data]);
  };

  // customAxios();

  React.useEffect(() => {
    callSleepTimes();
  }, []);

  /**********************************PROMISE  ***************************************/
  // const sleep_times_response = fetch(options);
  // console.log("==========================1");
  // console.log(sleep_times_response); // PROMISE PENDING 상태일거임
  // console.log("==========================2");
  // sleep_times_response
  //   .then((result) => {
  //     console.log(result);
  //     return result.json();
  //   })
  //   .then((jsonResult) => {
  //     console.log(jsonResult);
  //   });
  // console.log("==========================3");

  /**********************************XMLHttpRequest  ***************************************/
  // fetch(options).then((response) => console.log(response));

  // axios(options).then((response) => console.log(response));

  // let promise = new Promise((resolve, reject) => {
  //   window.setTimeout(() => {
  //     resolve("SUCCESS!!!");
  //   }, 1000);
  //   console.log("나 지금 PROMISE 안에 있어~ !");
  // });

  // console.log("START===========");
  // promise.then((res) => {
  //   console.log(`result ::: ${res}`);
  // });
  // 별도의 패키지 존재함. XMLHTTPRequest 를 내부적으로 일부 사용중

  /*
  오래된 XMLHttpRequest

  React.useEffect(() => {
    //xhr 객체 생성
    let xhr = new XMLHttpRequest();

    // xhr 객체가 요청보내게 함( 요청 보낼수있게 구성을 했다!)
    xhr.open("GET", "http://localhost:5001/sleep_times");

    // xhr 객체가 실제 요청을 함
    xhr.send();
    console.log("호출되었다!");
    //xhr 객체가 응답을 기다리거나 받거나 등등 하고있음
    xhr.onreadystatechange = function (e) {
      console.log(xhr.readyState, "   e 값임");

      if (xhr.readyState == 4) {
        console.log("readyState 4. 요청끝남 응답받음");
      }
    };
  }, []);

  */

  const httpClient = axios.create({ baseURL: "http://localhost:5001/" });

  return (
    <div className="App">
      <button
        onClick={async () => {
          await addSleepTimes();
        }}
      >
        ADD SLEEP
      </button>
      <button
        onClick={async () => {
          const answer = await fetch(host + "/ping");

          console.log(await answer.json());
        }}
      >
        PING PONG
      </button>
      <button
        onClick={async () => {
          const response = await httpClient({
            method: "GET",
            // url: host + "/ping",
            url: "/ping",
          });
          console.log(response);
          console.log(await response.data);
        }}
      >
        AXIOS BUTTON
      </button>
      <button
        onClick={async () => {
          // const response = await axios.get(host + "/ping");
          const response = await httpClient.get("/ping");
          console.log(response);
          console.log(await response.data);
          const data = await response.data;
          console.log(data.answer);
        }}
      >
        AXIOS GET BUTTON
      </button>
      <hr />
      {sleepList.map((sleepItem, index) => {
        console.log(sleepItem);
        return (
          <h6 key={sleepItem.id + index}>
            {sleepItem.id}/{sleepItem.id + index} / {sleepItem.day}
          </h6>
        );
      })}
    </div>
  );
}

export default App;
