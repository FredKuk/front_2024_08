import React from "react";
import axios from "axios";

function App() {
  const [sleepList, setSleepList] = React.useState([]);
  const getSleepList = async () => {
    const response = await axios.get("http://localhost:5001/sleep_times");

    console.log(response);
    setSleepList(response.data);
  };
  //   const getSleepList = () => {
  //     const response = axios
  //       .get("http://localhost:5001/sleep_times")
  //       .then((result) => {
  //         console.log(result);
  //       });

  //     console.log(response);
  //   };

  const addSleepData = async () => {
    console.log(`sleepLIST!? : ${sleepList} , ${sleepList.length}`);
    const data = {
      id: "10",
      day: "Sunday",
      time: "7:30",
    };

    const response = await axios.post(
      "http://localhost:5001/sleep_times",
      data
    );

    if (response.status === 201) {
      setSleepList((prevList) => {
        const newSleepList = [...prevList, response.data];
        console.log(
          `newSleepList!? : ${newSleepList} , ${newSleepList.length}`
        );
        return newSleepList;
      });
    }
    console.log(`sleepLIST!? : ${sleepList} , ${sleepList.length}`);
  };

  React.useEffect(() => {
    if (sleepList.length == 0) {
      return;
    }
    console.log(sleepList.length, sleepList);
  }, [sleepList]);

  React.useEffect(() => {
    getSleepList();
  }, []);
  return (
    <div className="App">
      {sleepList.map((item, index) => {
        return (
          <h1 key={index}>
            {item.time} / {item.day}
          </h1>
        );
      })}
      <button
        onClick={() => {
          addSleepData();
        }}
      >
        ADD SLEEP DATA
      </button>
    </div>
  );
}
export default App;
