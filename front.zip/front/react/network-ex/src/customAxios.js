import axios, { AxiosHeaders } from "axios";

const customAxios = axios.create({
  baseURL: "http://localhost:5001/",
  headers: { ...AxiosHeaders },
});

export default customAxios;
