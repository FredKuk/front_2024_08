import React from "react";
import "./App.css";
import { ErrorBoundary } from "react-error-boundary";

const ErrorFallBack = ({ error: error }: { error: Error }) => {
  console.log(error);
  return (
    <div style={{ background: "red" }}>
      <div>{error.message}</div>
      <div>{error.name}</div>
      <div>{error.stack}</div>
    </div>
  );
};

const MyComponent = () => {
  React.useEffect(() => {
    throw new Error("5보다 크면안됨");
  }, []);
  return <div>Hello</div>;
};

function App() {
  // try {
  //   const a = 100;
  //   console.log(a);
  //   throw new Error("5보다 크면안됨");
  //   // throw Error;
  // } catch (err) {
  //   console.log(err);
  // } finally {
  //   console.log("dfdfd");
  // }
  return (
    <div className="App">
      <ErrorBoundary FallbackComponent={ErrorFallBack}>
        <MyComponent />
      </ErrorBoundary>
    </div>
  );
}

export default App;
