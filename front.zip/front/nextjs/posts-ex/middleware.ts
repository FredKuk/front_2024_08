import { NextRequest, NextResponse } from "next/server";

//URL 디코드, img, sentry 로딩할때 유저위치정보,

export function middleware(req: NextRequest) {
  //   console.log("================================================");
  //     console.log(req);
  //   console.log("1");
  //   console.log("================================================");
  return NextResponse.next();
}

export const config = {
  matcher: "/:path*",
};
