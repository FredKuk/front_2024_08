import customAxios from "@/app/components/customAxios";
import Board from "./Board";
import Link from "next/link";

// async function getPodList(): Promise<Post[]> {
//   await new Promise((resolve) => setTimeout(resolve, 2000));
//   const response = await customAxios.get("/posts");
//   const result: Post[] = await response.data;
//   //   console.log(result);
//   return result;
// }

const BoardList = async () => {
  // throw new Error();
  // const res = async () => {
  //   const response = await customAxios.get("/posts");
  //   console.log(response.data);
  //   const result: Post[] = response.data;
  //   return result;
  // };
  // console.log(res);
  // 1.// const posts = await res();
  // 2.//const posts = await getPodList();
  const response = await customAxios.get("/posts");
  console.log(response);
  const posts = await response.data;

  return (
    <div className="container">
      <Link href="/write">
        <button>ADD POST</button>
      </Link>
      {posts.map((post: Post, index: number) => {
        return <Board key={`post_${index}`} post={post} />;
      })}
    </div>
  );
};

export default BoardList;
