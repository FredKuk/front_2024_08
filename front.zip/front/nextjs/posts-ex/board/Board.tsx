import { redirect } from "next/navigation";
import Link from "next/link";

async function deletePost(id: string | number) {
  "use server"; // 옛날....
  const response = await fetch(`http://localhost:3000/api/posts/${id}`, {
    method: "DELETE",
  });
  const result = await response.json();
  console.log("DELETE RESULT :::", result);
  redirect("/"); // 삭제 후 홈페이지로 리다이렉트
}

const Board = ({ post: { title, content, writer, id } }: { post: Post }) => {
  return (
    <div className="post-item" style={{ background: "beige" }}>
      <p>{title}</p>
      <p>{content}</p>
      <p>{writer}</p>
      <p>{id}</p>
      <Link href={`/edit/${id}`}>
        <button>수정하기</button>
      </Link>
      <br />
      <form action={deletePost.bind(null, id!)}>
        <button type="submit">삭제하기</button>
      </form>
    </div>
  );
};

export default Board;

// "use client";
// // import Link from "next/link";
// import { useRouter } from "next/navigation";

// const Board = ({ post: { title, content, writer, id } }: { post: Post }) => {
//   const router = useRouter();

//   const deletePost = async (id: string | number) => {
//     const response = await fetch(`http://localhost:3000/api/posts/${id}`, {
//       method: "DELETE",
//     });
//     console.log("DELETE RESPONSE :::", response);
//     const result = await response.json();
//     console.log("DELETE RESULT :::", result);
//   };

//   return (
//     <div className="post-item" style={{ background: "blue" }}>
//       <p>{title}</p>
//       <p>{content}</p>
//       <p>{writer}</p>
//       <p>{id}</p>
//       {/* <Link href={`/edit/${id}`}>
//         <button>수정하기</button>
//       </Link> */}
//       <button
//         onClick={() => {
//           router.push(`/edit/${id}`);
//         }}
//       >
//         수정하기
//       </button>
//       <br></br>
//       <button
//         onClick={() => {
//           if (id) {
//             deletePost(id);
//           }
//         }}
//       >
//         삭제하기
//       </button>
//     </div>
//   );
// };
// export default Board;
