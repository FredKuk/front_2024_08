import BoardList from "@/board/BoardList";

export const revalidate = 1; //60초//
// 캐싱옵션
// 거의 무조건 : force-cache : {cache : "force-cache"}
// 저장 안함 : no-store :
// 특정 시간  : {next : {revalidate:3}}//second 기준

export default function Home() {
  return (
    <main>
      <h4>MAIN 홈페이지 입니다/ ROOT.page</h4>
      <BoardList />
    </main>
  );
}
