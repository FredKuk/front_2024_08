export default async function NotFound() {
  return (
    <div>
      <h3>없는 페이지네용?</h3>
    </div>
  );
}
