export default function MainPostsLoading() {
  return (
    <div>
      <h2>Root Loading</h2>
    </div>
  );
}
