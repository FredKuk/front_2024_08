//email
//pw

import { signIn } from "next-auth/react";

//name
export default function RegisterPage() {
  // React.useEffect()

  const login = async () => {
    const result = await signIn("credentials", {
      redirect: false,
      email: "dev@dev.com",
      password: "hihi",
    });
    console.log(result);
  };
  return (
    <div>
      <h3>회원가입페이지</h3>
      <form>
        {/* <form method="POST" action="/api/auth/signup"> */}
        <input name="name" type="text" placeholder="이름" />
        <input name="email" type="text" placeholder="이메일" />
        <input name="password" type="password" placeholder="비번" />
        <button
          type="submit"
          onClick={() => {
            login();
          }}
        >
          id/pw 가입요청
        </button>
      </form>
    </div>
  );
}
