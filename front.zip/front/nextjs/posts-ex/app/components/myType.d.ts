type Post = {
  id?: string;
  title: string;
  content: string;
  writer: string;
};
