import axios, { AxiosHeaders, AxiosInstance } from "axios";

const customAxios: AxiosInstance = axios.create({
  baseURL: "http://localhost:5001/",
  headers: { ...AxiosHeaders },
});

export default customAxios;
