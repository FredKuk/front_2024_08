"use client"; //hydrate 할거야
import { useRouter } from "next/navigation";
import { useRef, useEffect, useState } from "react";

export default function WritePage() {
  return (
    <div>
      <form action="/api/formposts" method="POST">
        <div>
          <label>Title</label>
          <input name="title" />
        </div>
        <div>
          <label>Content</label>
          <textarea name="content" />
        </div>
        <div>
          <label>Writer</label>
          <input name="writer" />
        </div>
        <button
          type="submit" // Added type="button" to prevent default form submission behavior
        >
          작성완료
        </button>
      </form>
    </div>
  );
}
