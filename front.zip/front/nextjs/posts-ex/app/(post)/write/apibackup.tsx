"use client"; //hydrate 할거야
import { useRouter } from "next/navigation";
import { useRef, useEffect, useState } from "react";

export default function WritePage() {
  const router = useRouter();

  const t = useRef<HTMLInputElement>(null);
  const c = useRef<HTMLTextAreaElement>(null);
  const w = useRef<HTMLInputElement>(null);

  const getInputValues = () => {
    return {
      title: t.current?.value,
      content: c.current?.value,
      writer: w.current?.value,
    };
  };
  const sendPostData = async () => {
    const postData = getInputValues();
    console.log(postData);
    const response = await fetch("http://localhost:3000/api/posts", {
      method: "POST",
      body: JSON.stringify(postData),
    });
    console.log(response);
    const result = await response.json();
    console.log(result);
  };

  return (
    <div>
      <form>
        <div>
          <label>Title</label>
          <input ref={t} name="title" />
        </div>
        <div>
          <label>Content</label>
          <textarea ref={c} name="content" />
        </div>
        <div>
          <label>Writer</label>
          <input ref={w} name="writer" />
        </div>
        <button
          type="button" // Added type="button" to prevent default form submission behavior
          onClick={async () => {
            await sendPostData();
          }}
        >
          ADD POST
        </button>
      </form>
    </div>
  );
}
