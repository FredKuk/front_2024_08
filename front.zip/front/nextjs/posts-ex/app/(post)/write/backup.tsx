"use client"; //hydrate 할거야
import { useRef, useEffect, useState } from "react";

export default function WritePage() {
  const [newPost, setNewPost] = useState<Post>();
  const t = useRef<HTMLInputElement>(null);
  const c = useRef<HTMLTextAreaElement>(null);
  const w = useRef<HTMLInputElement>(null);

  function addPost(newData: Post = { title: "", content: "", writer: "" }) {
    setNewPost(newData);
  }

  useEffect(() => {
    const response = fetch("http://localhost:5001/posts", {
      method: "POST",
      body: JSON.stringify(newPost),
    });
    console.log(newPost);
  }, [newPost]);

  console.log("asdfasdf", newPost);
  return (
    <div>
      <form>
        <div>
          <label>Title</label>
          <input ref={t} name="title" />
        </div>
        <div>
          <label>Content</label>
          <textarea ref={c} name="content" />
        </div>
        <div>
          <label>Writer</label>
          <input ref={w} name="writer" />
        </div>
        <button
          type="button" // Added type="button" to prevent default form submission behavior
          onClick={() => {
            if (t.current && c.current && w.current) {
              addPost({
                title: t.current.value || "",
                content: c.current.value || "",
                writer: w.current.value || "",
              });
            }
          }}
        >
          ADD POST
        </button>
      </form>
    </div>
  );
}
