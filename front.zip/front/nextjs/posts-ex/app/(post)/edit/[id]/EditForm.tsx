"use client";
import React from "react";
import { useRouter } from "next/navigation";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";

export default function EditForm({ data }: { data: Post }) {
  const titleRef = React.useRef<HTMLInputElement>(null);
  const contentRef = React.useRef<HTMLTextAreaElement>(null);
  const writerRef = React.useRef<HTMLInputElement>(null);
  const router: AppRouterInstance = useRouter();
  React.useEffect(() => {
    // todo ::ref 접근하여 각 인풋요쇼들에 값 넣어줄것;
    if (!titleRef.current || !contentRef.current || !writerRef.current) {
      return;
    }
    titleRef.current.value = data.title;
    contentRef.current.value = data.content;
    writerRef.current.value = data.writer;
  }, []);
  const edit = async () => {
    const editedPost = getEditedPost();
    const response = await fetch(`http://localhost:3000/api/posts/${data.id}`, {
      method: "PUT",
      body: JSON.stringify(editedPost),
    });
    console.log(response);
    if (response.ok) {
      const result = await response.json();
      console.log("EDIT RESULT ::: ", result);
      router.back();
    }
  };
  function getEditedPost() {
    if (!titleRef.current || !contentRef.current || !writerRef.current) {
      return;
    }
    const editedPost: Post = {
      title: titleRef.current?.value,
      content: contentRef.current?.value,
      writer: writerRef.current?.value,
    };
    return editedPost;
  }
  return (
    <div>
      <h1>EDIT FORM</h1>
      <hr></hr>
      <input name="title" ref={titleRef} />
      <br />
      <textarea name="content" ref={contentRef} />
      <br />
      <input name="writer" ref={writerRef} />
      <hr />
      <button
        onClick={() => {
          edit();
        }}
      >
        수정하기
      </button>
    </div>
  );
}
