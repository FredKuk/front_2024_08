"use client";
export default function Error({
  error,
  reset,
}: {
  error: Error;
  reset: () => {};
}) {
  console.log(error);
  console.log(reset);
  return <div>ERROR!!입니다</div>;
}
