import NextAuth, { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { JWT } from "next-auth/jwt";

// 사용자 타입 정의
interface User {
  id: number;
  name: string;
  email: string;
  password: string; // 실제 서비스에서는 이 필드를 보관하지 않는 것이 좋습니다.
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      //1. 로그인 페이지 폼 자동 생성해주는 코드
      name: "credentials",
      credentials: {
        email: { label: "email", type: "text" },
        password: { label: "password", type: "password" },
      },

      //2. 로그인 요청 시 실행되는 코드
      // 직접 DB에서 아이디, 비번 비교하고
      // 아이디, 비번 맞으면 return 결과, 틀리면 return null 해주시면 됩니다!
      async authorize(credentials): Promise<any> {
        // 사용자를 하드코딩된 예제로 처리합니다.
        const user: User = {
          id: 1,
          name: "Jung",
          email: "test@test.com",
          password:
            "$2b$10$Vz5e3v5qU2f8Zp9H6m9ZyO4VJ1mM8X3YK5sZ1u4t6g2V5V5z5y5e5", // 암호화된 비밀번호
        };

        if (!credentials) {
          console.log("잘못된 입력값");
          return null;
        }

        if (!user) {
          console.log("해당 이메일은 없음");
          return null;
        }

        const pwcheck = await bcrypt.compare(
          credentials.password,
          user.password
        );
        // if (!pwcheck) {
        //   console.log('비밀번호 틀림');
        //   return null;
        // }

        return user;
      },
    }),
  ],

  //3. JWT 설정 (+ 만료일 설정)
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30일
  },

  callbacks: {
    //4. JWT 생성 시 실행되는 코드
    // JWT 토큰에 사용자 정보를 추가하는 건데, 필요한 정보가 있으면 더 추가하면 됩니다!
    jwt: async ({ token, user }) => {
      if (user) {
        token.user = {
          name: user.name,
          email: user.email,
        };
      }
      return token;
    },
    //5. 세션이 생성될 때마다 실행되는 코드
    // 토큰에서 유저 정보를 땡겨가요!
    session: async ({ session, token }) => {
      if (token.user) {
        session.user = token.user;
      }
      return session;
    },
  },
  //6. 비밀 키 (JWT 암호화 시 사용)
  // 요건 비밀키인데, 실제로는 노출되면 안되는 값이라서 .env에 넣어주시는 게 좋아요!
  secret: "qwer1234",
  // 여기는 어떤 DB를 사용할지 설정하는 부분인데, Prisma를 사용하면 prisma로 설정하시면 됩니다!
  // 몽고 디비 쓰시면 몽고디비로!
  // adapter: 'prisma',
};

export default NextAuth(authOptions);
