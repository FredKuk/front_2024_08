import { NextApiRequest, NextApiResponse } from "next";
import bcrypt from "bcryptjs";
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  /*
        1. 가입하는척 하기 위해 비밀번호 암호화 할 것
        2. 유저정보 받아 온 것 말고 아무거나 막 만들어서 리턴해보기로함(테스트)
        3. 
    */
  const hashPwd = await bcrypt.hash(req.body.password, 10);
  console.log("hashPwd ::: ", hashPwd);
  res.status(200).json({ message: "SUCCESS" });
}
