//import type {}
// mock api 를 호출하는 쪼꼬미 API

import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  console.log("METHOD::::", req.method);
  console.log("HEADER :::\n", req.headers);
  console.log("BODY :::\n", req.body);
  console.log("QUERY :::\n", req.query);

  if (req.method === "POST") {
    const { title, content, writer } = req.body;
    if (!title || !content || !writer) {
      console.log(title, content, writer);
      return res
        .status(400)
        .json({ data: req.body, error: "데이터 누락 있음" });
    }
    const response = await fetch("http://localhost:5001/posts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title,
        content,
        writer,
      }),
    });
    console.log(response);
    if (response.ok) {
      //  페이지 이동 302, 계속해서 post 날릴땐 307
      //  res.redirect(302, "/");
    }
  }

  console.log("TEST임");
}
