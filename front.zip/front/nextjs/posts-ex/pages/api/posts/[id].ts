// post-ex/pages/api/[id].ts

import { NextApiRequest, NextApiResponse } from "next";

// 요 함수는 기본적으로 async 붙어있다고 보면 됨
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const { id } = req.query;
  console.log("ID :::::", id);

  if (req.method === "GET") {
    const response = await fetch(`http://localhost:5001/posts/${id}`);
    if (response.ok) {
      const result = await response.json();
      console.log("RESULT :::", result);
      return res.status(200).json({ ...result });
    } else {
      console.log(response);
    }
  } else if (req.method === "PUT") {
    const jsonBody = JSON.parse(req.body);
    const response = await fetch(`http://localhost:5001/posts/${id}`, {
      method: "PUT",
      body: JSON.stringify(jsonBody),
    });

    if (response.ok) {
      const result = await response.json();
      console.log("RESULT :::", result);
      return res.status(200).json({ ...result, message: "데이터 잘 고쳤음" });
    } else {
      console.log(response);
    }
  } else if (req.method === "DELETE") {
    const response = await fetch(`http://localhost:5001/posts/${id}`, {
      method: "DELETE",
    });
    if (response.ok) {
      res.status(200).json({ message: "삭제 성공함" });
    }
  } else {
    res.setHeader("Allow", ["GET", "PUT"]);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
  console.log("EDIT PAGE 끝남");
  // res.status(405).json({ message: `id : ${id} // 데이터 잘못보내주심` });

  res.status(405).end(`id : ${id} // 데이터 잘못보내주심`);
}
