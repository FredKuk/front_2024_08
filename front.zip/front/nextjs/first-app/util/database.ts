import { Db, MongoClient } from "mongodb";
const connectDB = new MongoClient("192.168.0.1@1234");

const sample_airbnb: Db = connectDB.db("sample_airbnb");

sample_airbnb.collection("test").find;
