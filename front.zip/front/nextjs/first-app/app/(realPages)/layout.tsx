export default function PageLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div>
      <h1>페이지레이아웃</h1>
      <div style={{ background: "aliceblue" }}>{children}</div>
    </div>
  );
}
