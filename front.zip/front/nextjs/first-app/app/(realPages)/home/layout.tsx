// export default function HomeLayout() {
//   return (
//     <div>
//       <h3>LAYOUT</h3>
//     </div>
//   );
// }

export default function HomeLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <div>
      <h3>나는 홈 레이아웃이야</h3>
      {children}
    </div>
  );
}
