import Header from "@/app/components/Header";
import Link from "next/link";

export default function HomePage() {
  console.log("HOME!!~");
  return (
    <div>
      <Header />
      <hr></hr>
      <a href="/cat">asdfasdf</a>
    </div>
  );
}
