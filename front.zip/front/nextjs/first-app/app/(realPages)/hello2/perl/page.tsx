export default function PerlPage() {
  return (
    <div>
      <h1>PERL CAT PAGE</h1>
    </div>
  );
}
