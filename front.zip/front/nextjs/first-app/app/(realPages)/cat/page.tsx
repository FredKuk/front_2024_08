import Link from "next/link";

// 고양이 배열
const cats = [
  { name: "나비", color: "LightCoral" },
  { name: "고등어", color: "SlateGray" },
  { name: "치즈", color: "Goldenrod" },
  { name: "까미", color: "Black" },
  { name: "하양이", color: "Ivory" },
];
export default function catListPage() {
  return (
    <div>
      {cats.map((cat, index) => {
        return (
          <Link key={index} href={`/cat/${cat.name}`}>
            <p style={{ color: cat.color }}>
              <h1>{cat.name}</h1>
            </p>
          </Link>
        );
      })}
    </div>
  );
}
