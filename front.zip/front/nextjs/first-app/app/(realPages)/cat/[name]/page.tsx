// "use client"; // csr로 쓸때
export default function CatPage({
  params: { name: name },
}: // searchParams,
{
  params: { name: string };
  // searchParams: object;
}) {
  const decodeUrl = decodeURIComponent(name);
  console.log("decode URL :: ", decodeUrl);
  return (
    <div>
      <h1>THIS IS CAT PAGE [{decodeUrl}]</h1>
      <h1>THIS IS CAT PAGE {decodeUrl}</h1>
    </div>
  );
}
