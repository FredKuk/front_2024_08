// "use client"; // csr로 쓸때
export default function DogPage({
  params: { name: name },
  searchParams: searchParamsString,
}: // searchParams,
{
  params: { name: string };
  searchParams: Record<string, string | undefined>;
  // searchParams: object;
}) {
  const decodeUrl = decodeURIComponent(name);
  console.log(searchParamsString);
  console.log("decode URL :: ", decodeUrl);
  return (
    <div>
      <h1>{searchParamsString.abc}</h1>
      <h1>THIS IS DOG PAGE [{decodeUrl}]</h1>
      <h1>THIS IS DOG PAGE {decodeUrl}</h1>
    </div>
  );
}

// "use client"; // csr로 쓸때
// export default function DogPage(props: any) {
//   console.log(props);
//   return (
//     <div>
//       <h1>sdfasdf</h1>
//     </div>
//   );
// }
