"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";

const dogs = [
  { name: "나비", color: "LightCoral" },
  { name: "고등어", color: "SlateGray" },
  { name: "치즈", color: "Goldenrod" },
  { name: "까미", color: "cyan" },
  { name: "하양이", color: "Ivory" },
];

export default function DogPage() {
  const router = useRouter();
  console.log(router);
  return (
    <div>
      <h1>DOG PAGE</h1>
      <button
        onClick={() => {
          // router.replace()//히스토리를 쌓지 않음
          // router.back()
          router.push("/home");
        }}
      >
        HOME BUTTON
      </button>
      {dogs.map((dog, index) => {
        return (
          <Link key={index} href={`/dog/${dog.name}`}>
            <p style={{ background: dog.color }}>{dog.name} 상세페이지</p>
            <hr />
          </Link>
        );
      })}
    </div>
  );
}
