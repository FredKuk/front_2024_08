async function fetchSleepData() {
  const pr = await new Promise((resolve, reject) => {
    setTimeout(() => resolve(true), 3000);
  });
  const response = await fetch("http://localhost:5001/sleep_times");
  const result = await response.json();
  return result;
}
export default async function Sleep2Page() {
  const result = await fetchSleepData();
  return (
    <div>
      <h2>SLEEP 2 COMPONENT</h2>

      {result.map((item: { id: String; time: string }, index: number) => {
        return <p key={index}>{item.time}</p>;
      })}
      <h1>END</h1>
    </div>
  );
}
