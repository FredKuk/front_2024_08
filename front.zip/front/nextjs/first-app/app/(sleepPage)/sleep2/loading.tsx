export default function SleepLoading() {
  return (
    <div>
      <h2>SLEEP 2 LOADING NOW</h2>
    </div>
  );
}
