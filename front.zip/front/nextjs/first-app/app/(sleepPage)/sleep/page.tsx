"use client";
import React from "react";

type SleepTime = {
  id: string;
  day: string;
  time: string;
};

export default function SleepPage() {
  const [sleepTimes, setSleepTimes] = React.useState<SleepTime[]>([]);
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    fetch("http://localhost:5001/sleep_times")
      .then((res) => {
        console.log(res);
        return res.json();
      })
      .then((res) => {
        console.log(res);
        setIsLoading(false);
        setSleepTimes(res);
      });
  }, []);
  if (isLoading) {
    return <h1>로딩중임니다</h1>;
  }
  return (
    <div>
      Sleep
      {sleepTimes.map((sleepTime: SleepTime, index) => {
        return (
          <div key={index}>
            <p>{sleepTime.day}</p>
            <p>{sleepTime.id}</p>
            <p>{sleepTime.time}</p>
          </div>
        );
      })}
    </div>
  );
}

// "use client";
// import React from "react";

// type SleepTime = {
//   id: string;
//   day: string;
//   time: string;
// };

// export default function SleepPage() {
//   const [sleepTimes, setSleepTimes] = React.useState<SleepTime[]>([]);
//   const [isLoading, setIsLoading] = React.useState<boolean>(true);

//   React.useEffect(() => {
//     fetch("http://localhost:5001/sleep_times")
//       .then((res) => res.json())
//       .then((data) => {
//         setSleepTimes(data);
//         setIsLoading(false);
//       })
//       .catch((error) => {
//         console.error("Error fetching sleep times:", error);
//         setIsLoading(false);
//       });
//   }, []);

//   return (
//     <div>
//       Sleep
//       {isLoading ? (
//         <p>Loading...</p>
//       ) : (
//         sleepTimes.map((sleepTime: SleepTime, index) => (
//           <div key={index}>
//             <p>{sleepTime.day}</p>
//             <p>{sleepTime.id}</p>
//             <p>{sleepTime.time}</p>
//           </div>
//         ))
//       )}
//     </div>
//   );
// }
