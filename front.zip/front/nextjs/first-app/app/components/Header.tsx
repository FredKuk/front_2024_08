import Link from "next/link";

export default function Header() {
  return (
    <div>
      <Link href="/home">Home ---</Link>
      <hr></hr>
      <Link href="/cat/나비">CAT ---</Link>
      <hr></hr>
      <Link href="/dog">DOG ---</Link>
      <hr></hr>
      <Link href="/sleep">SLEEP ---</Link>
      <hr></hr>
    </div>
  );
}
